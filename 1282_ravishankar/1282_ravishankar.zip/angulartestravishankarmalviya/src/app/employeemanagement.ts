export  class  Employeemanagement {
    id: number;
    orgname:  string;
    dateoftraining:  string;
    placeoftraning : string;
    purposeoftraining: string;
    employee:string;
}
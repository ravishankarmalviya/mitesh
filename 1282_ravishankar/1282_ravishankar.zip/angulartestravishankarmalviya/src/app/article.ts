export interface Article {
    id: number;
    title: string;
    category: string;
    writer: string;
    

} 
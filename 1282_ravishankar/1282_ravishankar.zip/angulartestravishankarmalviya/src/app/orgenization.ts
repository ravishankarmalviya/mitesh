export interface Orgenization {
    id: number;
    name: string;
    
    

} 